#ifndef _LEVEL2_H_
#define _LEVEL2_H_

#include <genesis.h>
#include "globals.h"
#include "gameobject.h"
#include "resources.h"

// Top-Left screen position in map
// extern u16 screen_x;
// extern u16 screen_y;

extern TileMap* tilemap;

u16 LEVEL2_init(u16 ind);

#endif