#include "gameobject.h"
#include "utils.h"

u8 buttons[NUMBER_OF_JOYPADS];
u8 buttons_old[NUMBER_OF_JOYPADS];

char line[MAX_TEXT_LINE] = {0};
