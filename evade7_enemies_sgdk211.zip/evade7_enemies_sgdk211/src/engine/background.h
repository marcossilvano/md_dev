#ifndef _BACKGROUND_H_
#define _BACKGROUND_H_

#include <genesis.h>
#include "globals.h"
#include "resources.h"

u16 BACKGROUND_init(u16 ind);
void BACKGROUND_update();

#endif